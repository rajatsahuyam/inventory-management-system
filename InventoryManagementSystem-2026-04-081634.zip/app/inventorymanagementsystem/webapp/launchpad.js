sap.ui.define([
    "sap/m/Shell",
    "sap/m/App",
    "sap/m/Page",
    "sap/m/GenericTile",
    "sap/m/TileContent",
    "sap/m/NumericContent",
    "sap/m/FlexBox"
], function(Shell, App, Page, GenericTile, TileContent, NumericContent, FlexBox) {
    "use strict";

    const BASE = "/odata/v4/inventory";

    async function fetchCount(entity, filter) {
        const url = filter
            ? `${BASE}/${entity}/$count?$filter=${encodeURIComponent(filter)}`
            : `${BASE}/${entity}/$count`;
        const res = await fetch(url, { credentials: "include" });
        return res.ok ? parseInt(await res.text()) : "—";
    }

    function createTile(config) {
        const numericContent = new NumericContent({
            value: "...",
            valueColor: config.valueColor || "None",
            scale: "",
            withMargin: false
        });

        const tile = new GenericTile({
            header: config.title,
            subheader: config.subtitle,
            frameType: "OneByOne",
            tileContent: new TileContent({
                footer: config.footer || "",
                content: numericContent
            }),
            press: function() {
                window.location.href = "index.html" + config.route;
            }
        });

        // store reference to update later
        tile._numericContent = numericContent;
        return tile;
    }

    // Define tiles
    const tiles = {
        products: createTile({
            title: "Products",
            subtitle: "Manage Inventory",
            footer: "Total Products",
            route: "#/Products",
            valueColor: "None"
        }),
        lowStock: createTile({
            title: "Low Stock",
            subtitle: "Needs Attention",
            footer: "Products",
            route: "#/Products",
            valueColor: "Critical"
        }),
        outOfStock: createTile({
            title: "Out of Stock",
            subtitle: "Requires Restock",
            footer: "Products",
            route: "#/Products",
            valueColor: "Error"
        }),
        orders: createTile({
            title: "Orders",
            subtitle: "Manage Orders",
            footer: "Total Orders",
            route: "#/Orders",
            valueColor: "None"
        }),
        pending: createTile({
            title: "Pending Orders",
            subtitle: "Awaiting Approval",
            footer: "Orders",
            route: "#/Orders",
            valueColor: "Critical"
        })
    };

    // Load live counts
    async function loadCounts() {
        try {
            const [
                totalProducts,
                outOfStock,
                totalOrders,
                pendingOrders,
                allProducts
            ] = await Promise.all([
                fetchCount("Products"),
                fetchCount("Products", "stock eq 0"),
                fetchCount("Orders"),
                fetchCount("Orders", "status eq 'N'"),
                fetch(`${BASE}/Products?$select=stock,criticalStock`, {
                    credentials: "include"
                }).then(r => r.json())
            ]);

            const lowStock = allProducts.value.filter(
                p => p.stock > 0 && p.stock < p.criticalStock
            ).length;

            tiles.products._numericContent.setValue(String(totalProducts));
            tiles.outOfStock._numericContent.setValue(String(outOfStock));
            tiles.lowStock._numericContent.setValue(String(lowStock));
            tiles.orders._numericContent.setValue(String(totalOrders));
            tiles.pending._numericContent.setValue(String(pendingOrders));

        } catch(e) {
            console.error("Failed to load tile counts", e);
        }
    }

    // Build the page
    const tileBox = new FlexBox({
        wrap: "Wrap",
        justifyContent: "Start",
        alignItems: "Start",
        items: Object.values(tiles)
    }).addStyleClass("sapUiSmallMargin");

    const page = new Page({
        title: "Inventory Management System",
        showHeader: true,
        content: [tileBox]
    });

    const app = new App({ pages: [page] });

    new Shell({
        app: app,
        appWidthLimited: false
    }).placeAt("content");

    loadCounts();
});